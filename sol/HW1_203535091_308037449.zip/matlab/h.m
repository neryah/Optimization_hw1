% gets a scalar x and returns the value, first derivative and second
% derivative of h(x)=exp(x)
function [value, first_derivative, second_derivative] = h(x)
% value
value = exp(x);

% first_derivative
first_derivative = exp(x);

% second_derivative
second_derivative = exp(x);
end